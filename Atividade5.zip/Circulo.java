
public class Circulo {
	double r;

	public Circulo(double raio) {
		this.r = raio;
	}
	
	public Circulo() {
		this.r = 0;
	}

	public double getR() {
		return this.r;
	}

	public void setR(double r) {
		this.r = r;
	}
	
	public double Area() {
		return Math.PI * this.r * this.r;
	}
	
	public double Circuferencia() {
		return this.r*2*Math.PI;
	}
	
	public double Diametro() {
		return 2*this.r;
	}
	
	
}
