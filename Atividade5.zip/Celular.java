
public class Celular {
	double bateria;
	String notification;
	String nome;
	
	public Celular(String user) {
		this.nome = user;
		this.notification = "Sem notificações";
		this.bateria = 100;
	}

	public double getBateria() {
		return bateria;
	}

	public void setBateria(double bateria) {
		this.bateria = bateria;
	}

	public String getNotification() {
		return notification;
	}

	public void setNotification(String msg) {
		if (msg == null) {this.notification = "Sem notificações";}
		if (this.notification == "Sem notificações") {this.notification = "";}
		this.notification += "Nova notificação de: " + msg + "\n";
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	

	public void enviaMSG(String msg, Celular contato) {
		contato.setNotification(this.nome + ": " + msg);
		this.bateria -= msg.length()/5;
	}
}
