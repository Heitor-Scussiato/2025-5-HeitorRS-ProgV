import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		Scanner key = new Scanner(System.in);
		List<Celular> listaCel = new ArrayList<Celular>();
		
		System.out.print("Digite o raio do círculo: ");
		Circulo c1 = new Circulo(key.nextDouble());
		System.out.print("\n\n> Area do círculo: " + c1.Area());
		System.out.print("\n\n> Circuferencia do círculo: " + c1.Circuferencia());
		System.out.print("\n\n> Diametro do círculo: " + c1.Diametro());
		
		Circulo c2 = new Circulo();
		System.out.print("Digite o raio do círculo: ");
		c2.setR(key.nextDouble());
		System.out.print("\n\n> Raio do círculo: " + c2.getR());
		System.out.print("\n\n> Area do círculo: " + c2.Area());
		System.out.print("\n\n> Circuferencia do círculo: " + c2.Circuferencia());
		System.out.print("\n\n> Diametro do círculo: " + c2.Diametro());
		
		while (true) {
			boolean liga = false;
			System.out.print("\n\n\n\n\n\n\n\n\n\t --= TESTE CELULAR ==-");
			System.out.print("\n Digite o nome do celular: ");
			String celName = key.nextLine();
			Celular cel = null;
			for (int i=0;i<listaCel.size();i++) {
				if (listaCel.get(i).getNome().equalsIgnoreCase(celName)) {
					cel = listaCel.get(i);
					liga = true;
					break;
				}
			}
			if (cel != null) {
				System.out.print("\n Esse celular já existe, deseja usa-lo? (sim/nao): ");
				if (key.next().equalsIgnoreCase("sim")) {
					liga = true;
				} else {
					if (key.next().equalsIgnoreCase("sim")) {
						System.out.print("\n : ");
						Celular newCel = new Celular(celName);
						listaCel.add(newCel);
						liga = true;
						cel = newCel;
					}
				}
			}
			if (liga) {
				System.out.print("\n\n\n\n\n\n\n\n\n\t --= BEM-VINDO"+ cel.getNome() +" ==-");
				
				
				// Sistema de mensagens e notificações;
			}
		}
	}
}
